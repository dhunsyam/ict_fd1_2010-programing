﻿Public Class Frm_more_loops

    Private Sub btncalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncalculate.Click
        'Declare a loopcounter as a whole number…
        Dim LoopCounter As Integer
        Dim CurrentValue As Integer = NumericUpDown.Value
        Dim displaystring As String
        Dim Update As UpdateRowSource
        '…and a (whole number)variable to hold the chosen number

        'Clear out display area (e.g. Listbox)
        Rtb.Clear()
        'Initialise a varialbe to hold the Factorial as 1
        LoopCounter = 1

        'Get selected (whole number) value from user (e.g. using a 	NumericUpDown)
        Using (NumericUpDown)

            'start a loop to iterate up to selected number
            For LoopCounter = 1 To 9

            Next


            ' update Factorial value b multiplying rpevious result by current loopcounter value    
            Update = UpdateRowSource.FirstReturnedRecord


            ' create a formatted string to be displayed...
            displaystring = (Update) & " x " & (LoopCounter) & "  = " & (Update * LoopCounter)
            '... and display it
            displaystring = Rtb.Text
            'end of loop
            Do
                If LoopCounter > 9 Then
                    Exit Do
                End If

            Loop
            'format string to display final message “Factorial of x is y”
            Rtb.Text = Rtb.Text + ("Factorial of x is y")
            '... and display it
            Rtb.Text = Rtb.Text
        End Using
    End Sub
End Class
